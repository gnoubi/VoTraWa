# install.packages("devtools")
# devtools::install_github("choisy/gamar")
library(gamar)

#defpath("/Applications/Gama.app")
modelPath <- "../models"
defpath("C:/Program Files/GAMA1.7RC2.Windows.64bits")
experiment1 <- getmodelparameter(paste0(modelPath,"/campagnols.gaml"),"campagnols")


# day_unit <- 60 * 60 * 24

simulation_duration <- 365 * 14;

B<-1060

reproducer_death_rate<-runif(B,0.003,0.02)/24/60/60 # voir tableau excel essais erreur pour estimation de la fourchette

simulations<-data.frame(
  younger_death_rate=reproducer_death_rate*runif(B,1,3),
  juvenile_death_rate=reproducer_death_rate*runif(B,1,3),
  reproducer_death_rate=reproducer_death_rate,
  migration_threshold=runif(B,0.1,0.6), 
  creasy_vole_rate=runif(B,0,0.2),
  min_distance_crasy=rep(150,B),
  max_distance_crasy=runif(B,160,1000)
)

summary(simulations)


sim2 <- simulations

#sim2 <- simulations[!simulations$min_distance_crasy>simulations$max_distance_crasy,]


for (i in 1:nrow(sim2))
{
  local_experiment <-  setparametervalue(experiment1,"migration_threshold",sim2[i,"migration_threshold"])
  local_experiment <-  setparametervalue(local_experiment,"creasy_vole_rate",sim2[i,"creasy_vole_rate"])
  local_experiment <-  setparametervalue(local_experiment,"min_distance_creasy_vole",sim2[i,"min_distance_crasy"])
  local_experiment <-  setparametervalue(local_experiment,"max_distance_creasy_vole",sim2[i,"max_distance_crasy"])
  local_experiment <-  setparametervalue(local_experiment,"reproducer_death_rate",sim2[i,"reproducer_death_rate"])
  local_experiment <-  setparametervalue(local_experiment,"younger_death_rate",sim2[i,"younger_death_rate"])
  local_experiment <-  setparametervalue(local_experiment,"juvenile_death_rate",sim2[i,"juvenile_death_rate"])
  
  local_experiment <- setfinalstep(local_experiment,simulation_duration)
  
  local_experiment <- setoutputframerate(local_experiment,"discovered_area_year",365)
  local_experiment <- setoutputframerate(local_experiment,"densite_monitor",365)
  local_experiment <- setoutputframerate(local_experiment,"densite_occuped_monitor",365)  
  local_experiment <- setoutputframerate(local_experiment,"population_young_monitor",1)
  local_experiment <- setoutputframerate(local_experiment,"population_juvenile_monitor",1)
  local_experiment <- setoutputframerate(local_experiment,"population_reproducer_monitor",1)
  local_experiment <- setoutputframerate(local_experiment,"max_cell_population",1) 
  local_experiment <- setoutputframerate(local_experiment,"long_distance_dispersing_voles",1) 
  local_experiment <- setoutputframerate(local_experiment,"short_distance_dispersing_voles",1) 
  local_experiment <- setoutputframerate(local_experiment,"current_date",1)   
  local_experiment <- setoutputframerate(local_experiment,"discovered_area",1)
  local_experiment <- setoutputframerate(local_experiment,"campagnols_map",183)
  
  local_experiment <- setmodelpath(local_experiment,"../models/campagnols.gaml")
  
  local_experiment <- setsimulationid(local_experiment,i)
  
  local_experiment <- setseed(local_experiment,1)
  
  experimentplan <- addtoexperimentplan(local_experiment, id = i)
  
  outFile <- paste0("./input_",i,".xml")
  
  writemodelparameterfile(experimentplan,outFile)
}
